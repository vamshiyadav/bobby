package com.niit.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController 
{
	ModelAndView one;
	@RequestMapping(value="/")
	public ModelAndView discountData()
	{
		one = new ModelAndView("homePage");
		return one;
		
	}
	ModelAndView nj;
	@RequestMapping(value="/login")
	public ModelAndView loginfun()
	{
		nj = new ModelAndView("222");
		return nj;
	}

}

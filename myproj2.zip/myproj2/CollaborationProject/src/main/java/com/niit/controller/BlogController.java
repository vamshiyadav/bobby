package com.niit.controller;

import java.io.*;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.niit.model.*;
import com.niit.service.*;
import com.google.gson.Gson;

@Controller
public class BlogController 
{
	ModelAndView mv;

	@Autowired
	private BlogService blogservice;
	
	@Autowired
	UserService userService;

	@RequestMapping("/blog")
	public ModelAndView createBlog()
	{
		System.out.println("In Blog Controller");
		mv = new ModelAndView("BlogPage","blogKey",new Blog());
		return mv;
	}
	
	@ModelAttribute("blog")
	public Blog returnObject()
	{
		return new Blog();
	}

	@RequestMapping("/postb")
	public String postblog(@ModelAttribute("blog") Blog blog ,BindingResult br)
	{
		System.out.println("inside add blog");
		if(br.hasErrors())
		{
			System.out.println("It has errors");
			return null;
		}
		String activeUserName = SecurityContextHolder.getContext().getAuthentication().getName();
		User user = userService.getUserByname(activeUserName);
		Date date = new Date();
		blog.setCreationdatetime(date);
		blog.setBlogUserName(activeUserName);
		System.out.println("before forum save");
		blogservice.createNewBlog(blog);
		System.out.println("after blog save");
		return "redirect:/blog";
	}
	
	String setName;

	List<Blog> blist;
	@SuppressWarnings("unchecked")
	@RequestMapping("/GsonCon")
	public @ResponseBody String getValues()throws Exception
	{
		String result = "";
		
			
			blist = blogservice.getBlog();
			Gson gson = new Gson();			  
			result = gson.toJson(blist);			
		
		
		return result;
	}
	

	
}

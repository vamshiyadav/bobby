package com.niit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.User;
import com.niit.model.UserRole;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {
	
	public UserDaoImpl()
	{
		
	}
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	
	public void saveOrUpdate(User user) {
		// TODO Auto-generated method stub
		Session s1 =sessionFactory.getCurrentSession();
		Transaction t1 = s1.beginTransaction();
		s1.saveOrUpdate(user);
		UserRole u1= new UserRole();
		u1.setUserRoleId(user.getUserId());
		u1.setAuthority("ROLE_USER");
		s1.saveOrUpdate(u1);
		t1.commit();
	}

	public User getUserById(int userId) {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		Transaction t2=session.beginTransaction();
		User us=(User) session.load(User.class,userId);
		System.out.println("data of user by id="+us);
		t2.commit();
		return us;
	}

	
	public List<User> list() {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		Session session=this.sessionFactory.getCurrentSession();
		 @SuppressWarnings("unchecked")
		List<User> user = (List<User>) sessionFactory.getCurrentSession().createCriteria(User.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		 return user;
	}

	@SuppressWarnings("unchecked")
	public User getUserByname(String userName) {
		// TODO Auto-generated method stub
		System.out.println("getting data into Dao based on user name"+userName);
		Session session=this.sessionFactory.getCurrentSession();
		Transaction t3=session.beginTransaction();
		Query query = session.createQuery("from User where userName = '"+userName+"'");
		User user = (User) query.list().get(0);
		return user;
	}
	
	

}

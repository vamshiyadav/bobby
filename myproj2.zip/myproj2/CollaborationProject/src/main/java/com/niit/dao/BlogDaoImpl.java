package com.niit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Blog;

@Repository
@Transactional
public class BlogDaoImpl implements BlogDao{
	
	@Autowired 
	private SessionFactory sessionFactory;
	
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	

	@Override
	public void createNewBlog(Blog blog) {
		// TODO Auto-generated method stub
		Session session= sessionFactory.getCurrentSession();
		Transaction t1 = session.beginTransaction();
		System.out.println(blog);
		session.saveOrUpdate(blog);
		t1.commit();
		
	}

	@Override
	public List<Blog> getBlogList(String blogUserName) {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		Session session=this.sessionFactory.getCurrentSession();
		 @SuppressWarnings("unchecked")
		List<Blog> blog = (List<Blog>) sessionFactory.getCurrentSession().createCriteria(Blog.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		 return blog;
	}

	@Override
	public Blog getBlogById(int blogId) {
		// TODO Auto-generated method stub
		Session session=this.sessionFactory.getCurrentSession();
		Blog bl=(Blog) session.load(Blog.class,blogId);
		System.out.println("data of blog by id="+bl);
		return bl;
	}

	@Override
	public Blog getBlogByName(String blogUserName) {
		// TODO Auto-generated method stub
		System.out.println("getting data into Dao based on username");
		Session session=this.sessionFactory.getCurrentSession();
		Blog blog = (Blog) session.get(Blog.class, blogUserName);
		return blog;
	}

	@Transactional
	public void delete(int blogId) {
		// TODO Auto-generated method stub
		Blog blog = new Blog();
		sessionFactory.getCurrentSession().delete(blog);
		System.out.println("sucessfully deleted");
	}

	List<Blog> blogs;
	@SuppressWarnings("unchecked")
	public List<Blog> getBlog() {
		// TODO Auto-generated method stub
		System.out.println("In DAO Implementation");
		Session ss1 = sessionFactory.openSession();
		Query qry = ss1.createQuery("from Blog");
		System.out.println(qry.toString());
		blogs = (List<Blog>)qry.list();
		return blogs;
	}

}

package com.niit.dao;

import java.util.List;

import com.niit.model.User;

public interface UserDao {
	public void saveOrUpdate(User user);
	public User getUserById(int userId);
	public  List<User> list();
	public User getUserByname(String userName);

}

/**
 * 
 */

angular.module("chatApp", [
  "chatApp.controllers",
  "chatApp.services"
]);

angular.module("chatApp.controllers", []);
angular.module("chatApp.services", []);
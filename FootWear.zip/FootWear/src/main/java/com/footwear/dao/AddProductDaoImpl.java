package com.footwear.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.footwear.model.Item;

@Repository
public class AddProductDaoImpl implements AddProductDao{
	@Autowired
	SessionFactory sessionFactory;
	public void addItem(Item item) {
		System.out.println("i am in addproducts");
		Session session=sessionFactory.getCurrentSession();
		Transaction transaction=session.beginTransaction();
		session.save(item);
		transaction.commit();
		System.out.println("item added");
		
		
		
	}
	@Override
	public void addProduct(Item item) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public List<Item> viewItems() {
		Session session=sessionFactory.getCurrentSession();
		Transaction transaction=session.beginTransaction();
		List<Item> list=session.createCriteria(Item.class).list();
		return list;
	}
	

}

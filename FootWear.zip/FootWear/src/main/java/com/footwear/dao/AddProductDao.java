package com.footwear.dao;

import java.util.List;

import com.footwear.model.Item;

public interface AddProductDao {
	void addProduct(Item item);
	List<Item> viewItems();

}

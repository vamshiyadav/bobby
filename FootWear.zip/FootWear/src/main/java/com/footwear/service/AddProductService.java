package com.footwear.service;

import java.util.List;

import com.footwear.model.Item;


public interface AddProductService {
	void addItem(Item item);
	List<Item> viewItem();

}

package com.footwear.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.footwear.dao.AddProductDao;

import com.footwear.model.Item;


@Service
public class AddProductServiceImpl implements AddProductService{

	@Autowired
	AddProductDao addProductDao;
	public void addProduct(Item item) {
		addProductDao.addProduct( item);
		
	}

	public List<Item> viewItem() {
		List<Item>list=addProductDao.viewItems();
		return list;
	}

	@Override
	public void addItem(Item item) {
		// TODO Auto-generated method stub
		
	}

	

}

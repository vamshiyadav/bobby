package com.footwear.controller;

import java.io.IOException;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.footwear.model.Customer;
import com.footwear.model.Item;
import com.footwear.service.CustomerService;

@Controller
public class AdminController {
	@Autowired
	CustomerService cs;
	@RequestMapping("/addItem")
	public ModelAndView addItem(){
		Item item=new Item();
		return new ModelAndView("addItem","item",item);
		
	}
	
	@RequestMapping("/ViewCustomers")
	public ModelAndView vs() throws JsonGenerationException, JsonMappingException, IOException
	{
		List<Customer> list=cs.viewCustomers();
		System.out.println("List is:"+list);	
		ObjectMapper mapper=new ObjectMapper();
		String listJSON=mapper.writeValueAsString(list);
		System.out.println(listJSON);
		return new ModelAndView("/ViewCustomers","listOfCustomers",listJSON);
		
	}


}

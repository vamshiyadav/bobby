package com.niit.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.model.User;
import com.niit.service.UserService;



@Controller
public class HomeController {
	@Autowired
	UserService userservice;
	@RequestMapping("/")
	public ModelAndView home()
	{
		System.out.println("home page invoked");
		return new ModelAndView("home");
	}
	@RequestMapping("/login")
	public String loginMethod()
	{
		return "login";
	}

	@RequestMapping("/signUp")
	public ModelAndView signUp()
	{
		System.out.println("signUp() method called");
		return new ModelAndView("signup");
	}

	
	@RequestMapping("/register")
	public String createUser(@ModelAttribute("user") User user , Model model,HttpServletRequest request) throws IOException
	{
		
		/*String filename = null;
	    byte[] bytes;*/
	    
	    		user.setRole("ROLE_USER");
	    		user.setIsenabled(true);
	            userservice.saveOrUpdate(user);
	    		System.out.println("Data inserted and was saved");
	            //String path = request.getSession().getServletContext().getRealPath("/resources/images/" + user.getUserid() + ".jpg");
	    		/*MultipartFile image = user.getImage();
	            //Path path;
	            String path = request.getSession().getServletContext().getRealPath("/resources/images/"+user.getUserId()+".jpg");
	            System.out.println("Path="+path);
	            System.out.println("File name = " + user.getImage().getOriginalFilename());
	          
	            if(image!=null && !image.isEmpty())
	            {
	            	try
	            	{
	            		image.transferTo(new File(path.toString()));
	            		System.out.println("Image was saved  in:"+path.toString());
	            	}
	            	catch(Exception e)
	            	{
	            		e.printStackTrace();
	            		System.out.println("Image was not saved");
	            	}
	            }*/
	    	
	     	    
	    return "login";
	
		
	}

}

package com.niit.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Forum 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int forumId;
	@NotEmpty(message="forum title is required")
	private String forumTitle;
	@NotEmpty(message="forum content is required")
	private String forumContent;
	@NotEmpty(message="forum username is required")
	private String forumUserName;
	private Date creationdatetime;
	private String category;
	public int getForumId() {
		return forumId;
	}
	public void setForumId(int forumId) {
		this.forumId = forumId;
	}
	public String getForumTitle() {
		return forumTitle;
	}
	public void setForumTitle(String forumTitle) {
		this.forumTitle = forumTitle;
	}
	public String getForumContent() {
		return forumContent;
	}
	public void setForumContent(String forumContent) {
		this.forumContent = forumContent;
	}
	public String getForumUserName() {
		return forumUserName;
	}
	public void setForumUserName(String forumUserName) {
		this.forumUserName = forumUserName;
	}
	public Date getCreationdatetime() {
		return creationdatetime;
	}
	public void setCreationdatetime(Date creationdatetime) {
		this.creationdatetime = creationdatetime;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}


}

package com.niit.footwearbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.footwearbackend.dao.CategoryDAO;
import com.niit.footwearbackend.model.Category;

public class CategoryTest {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.footwearbackend.*");
		context.refresh();
		CategoryDAO categoryDAO = (CategoryDAO) context.getBean("categoryDAO");

		Category category = (Category) context.getBean("category");
		category.setId("45");
		category.setName("Footwear");
		category.setDescription("Online");

		categoryDAO.saveOrUpdate(category);
	}

}

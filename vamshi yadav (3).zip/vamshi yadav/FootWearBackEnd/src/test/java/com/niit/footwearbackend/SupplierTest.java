package com.niit.footwearbackend;

import java.util.function.Supplier;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SupplierTest 
{
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

		context.scan("com.niit.footwearbackend.*");
		context.refresh();
		SupplierDAO supplierDAO = (SupplierDAO) context.getBean("SupplierDAO");

		Supplier supplier = (Supplier) context.getBean("supplier");
		supplier.setId("45");
		supplier.setName("Footwear");
		supplier.setDescription("Online");

		supplierDAO.saveOrUpdate(supplier);
	}

}

package com.niit.footwearbackend.dao;



import java.util.List;

import com.niit.footwearbackend.model.Product;

public interface ProductDAO 
{
	public List<Product> List();
	public Product get(String id);
	public void saveOrUpdate(Product product);
	public void delete(String id);


}

package com.niit.footwearbackend.dao;



import java.util.List;

import com.niit.footwearbackend.model.Category;

public interface CategoryDAO 
{
	public List<Category> List();
	public Category get(String id);
	public void saveOrUpdate(Category category);
	public void delete(String id);


}

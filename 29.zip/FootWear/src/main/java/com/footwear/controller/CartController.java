package com.footwear.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.footwear.model.Cart;
import com.footwear.model.CartItem;
import com.footwear.model.Customer;
import com.footwear.model.Item;
import com.footwear.service.AddProductService;
import com.footwear.service.CartItemService;
import com.footwear.service.CustomerService;


@Controller
public class CartController {
	@Autowired
	CartItemService cartItemService;
	@Autowired
	AddProductService addProductService;
	@Autowired
	CustomerService customerService;
	@RequestMapping("/addtocart")
	public ModelAndView addItem(@RequestParam("id")int id)
	{
		String loggedInUserName=SecurityContextHolder.getContext().getAuthentication().getName();
		Customer customer=customerService.getCustomerByName(loggedInUserName);
		Cart cart=customer.getCart();
		Item item = addProductService.getItemById(id);
		CartItem cartItem=new CartItem();
		cartItem.setCart(cart);
		cartItem.setItem(item);
		cartItemService.addCartItem(cartItem);
		return null;
	}
	
}

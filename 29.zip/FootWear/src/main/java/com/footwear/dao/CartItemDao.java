package com.footwear.dao;

import com.footwear.model.CartItem;


public interface CartItemDao
{
	void addCartItem(CartItem cartItem);

}

package com.footwear.dao;

import com.footwear.model.Customer;

public interface CustomerDao {
	void addCustomer(Customer customer);

}

package com.footwear.service;

import com.footwear.model.Customer;

public interface CustomerService {
	void addCustomer(Customer customer);

}

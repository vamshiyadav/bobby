package com.footwear.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.footwear.dao.CustomerDao;
import com.footwear.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDao customerDao;
	public void addCustomer(Customer customer) {
		customerDao.addCustomer(customer);
	}

}
